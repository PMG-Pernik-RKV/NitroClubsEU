ROS_ VM_ and_ simulations_tutorials

NOTE: The documents in this repository are in: 

.odt OpenDocument Text
and 
.ods - OpenDocument Spreadsheet

file formats.

You can open them with any packages/programs supporting the OpenDocument format.
(i.e. LibreOffice, Microsoft Office and so on pakckages)